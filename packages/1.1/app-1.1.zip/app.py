#!/usr/bin/env python3
"""
app.py — Application principale v1.1
NOUVELLE VERSION — interface améliorée + historique des mises à jour
"""

import sys
import os
import json
import subprocess
import configparser
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import threading
from datetime import datetime

APP_VERSION = "1.1"
APP_NAME    = "MonApplication"

BASE_DIR    = Path(__file__).parent
CONFIG_FILE = BASE_DIR / "config.ini"
STATE_FILE  = BASE_DIR / "state.json"

BG       = "#0f1117"
BG2      = "#1a1f2e"
BG3      = "#12192a"
ACCENT   = "#0F6E56"   # Vert — indique la v1.1
ACCENT2  = "#48bb78"
GREEN    = "#48bb78"
AMBER    = "#f6ad55"
RED      = "#fc8181"
TEXT     = "#e2e8f0"
TEXT_DIM = "#718096"
BORDER   = "#2d3748"
BLUE     = "#185FA5"
BLUE2    = "#7EB8F7"

def load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    return {"installed_version": APP_VERSION, "history": []}

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

def check_update_available():
    try:
        import requests
        import urllib3
        urllib3.disable_warnings()

        cfg = configparser.ConfigParser()
        cfg.read(CONFIG_FILE, encoding="utf-8")
        server_url  = cfg["server"]["url"].rstrip("/")
        token       = cfg["server"]["token"]
        server_cert = cfg["server"].get("server_cert", "false")
        verify      = False if server_cert.lower() in ("false","no","0","") else server_cert

        headers = {"Authorization": f"Bearer {token}", "User-Agent": f"MonApp/{APP_VERSION}"}
        resp = requests.get(f"{server_url}/api/manifest", headers=headers,
                            verify=verify, timeout=5)
        resp.raise_for_status()
        manifest = resp.json()

        def parse(v):
            return tuple(int(x) for x in v.replace("v","").split("."))

        if parse(manifest.get("version","0.0")) > parse(APP_VERSION):
            return True, manifest
        return False, None
    except Exception:
        return False, None


class UpdateDialog(tk.Toplevel):
    def __init__(self, parent, manifest):
        super().__init__(parent)
        self.manifest = manifest
        self.result   = False
        self.title("Mise à jour disponible")
        self.resizable(False, False)
        self.configure(bg=BG)
        self.grab_set()
        W, H = 420, 310
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{W}x{H}+{(sw-W)//2}+{(sh-H)//2}")
        self._build()
        self.protocol("WM_DELETE_WINDOW", self._skip)

    def _build(self):
        version   = self.manifest.get("version","?")
        changelog = self.manifest.get("changelog",[])
        size_kb   = self.manifest.get("size",0) // 1024
        tk.Frame(self, bg=BLUE, height=6).pack(fill="x")
        tk.Label(self, text="🔄", font=("Segoe UI Emoji",28), bg=BG, fg=BLUE2).pack(pady=(16,4))
        tk.Label(self, text="Mise à jour disponible !",
                 font=("Segoe UI",14,"bold"), bg=BG, fg=TEXT).pack()
        tk.Label(self, text=f"Version {APP_VERSION}  →  Version {version}",
                 font=("Segoe UI",10), bg=BG, fg=TEXT_DIM).pack(pady=4)
        frame_cl = tk.Frame(self, bg=BG2)
        frame_cl.pack(fill="x", padx=24, pady=8)
        tk.Label(frame_cl, text="Nouveautés :", font=("Segoe UI",9,"bold"),
                 bg=BG2, fg=TEXT_DIM, anchor="w").pack(fill="x", padx=10, pady=(8,2))
        for item in (changelog or [f"Version {version}"]):
            tk.Label(frame_cl, text=f"  • {item}", font=("Segoe UI",9),
                     bg=BG2, fg=TEXT, anchor="w").pack(fill="x", padx=10)
        tk.Label(frame_cl, text=f"  Taille : {size_kb} Ko", font=("Segoe UI",8),
                 bg=BG2, fg=TEXT_DIM, anchor="w").pack(fill="x", padx=10, pady=(4,8))
        btn_frame = tk.Frame(self, bg=BG)
        btn_frame.pack(pady=12)
        tk.Button(btn_frame, text="Mettre à jour maintenant",
                  font=("Segoe UI",10,"bold"), bg=BLUE, fg="white", relief="flat",
                  padx=18, pady=8, cursor="hand2",
                  activebackground="#1a6fc4", activeforeground="white",
                  command=self._accept).pack(side="left", padx=6)
        tk.Button(btn_frame, text="Plus tard",
                  font=("Segoe UI",10), bg=BG2, fg=TEXT_DIM, relief="flat",
                  padx=18, pady=8, cursor="hand2",
                  activebackground=BORDER, activeforeground=TEXT,
                  command=self._skip).pack(side="left", padx=6)

    def _accept(self): self.result = True; self.destroy()
    def _skip(self):   self.result = False; self.destroy()


class ProgressDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Téléchargement en cours...")
        self.resizable(False, False)
        self.configure(bg=BG)
        self.grab_set()
        W, H = 380, 180
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{W}x{H}+{(sw-W)//2}+{(sh-H)//2}")
        tk.Label(self, text="⬇️", font=("Segoe UI Emoji",24), bg=BG, fg=BLUE2).pack(pady=(18,4))
        self.label = tk.Label(self, text="Connexion...", font=("Segoe UI",10), bg=BG, fg=TEXT)
        self.label.pack()
        self.bar = ttk.Progressbar(self, length=300, mode="determinate")
        self.bar.pack(pady=12)
        self.pct = tk.Label(self, text="0%", font=("Segoe UI",9), bg=BG, fg=TEXT_DIM)
        self.pct.pack()
        self.protocol("WM_DELETE_WINDOW", lambda: None)

    def update_progress(self, pct, msg=""):
        self.bar["value"] = pct
        self.pct.config(text=f"{pct:.0f}%")
        if msg: self.label.config(text=msg)
        self.update()

    def done(self):
        self.label.config(text="✓ Installation terminée !")
        self.bar["value"] = 100
        self.pct.config(text="100%", fg=GREEN)
        self.update()


class MainApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.resizable(False, False)
        self.configure(bg=BG)
        W, H = 560, 460
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{W}x{H}+{(sw-W)//2}+{(sh-H)//2}")
        self._build_ui()
        self.after(1000, self._check_update_async)

    def _build_ui(self):
        state = load_state()

        # Bande accent verte (nouvelle version !)
        tk.Frame(self, bg=ACCENT, height=4).pack(fill="x")

        # En-tête
        header = tk.Frame(self, bg=BG2)
        header.pack(fill="x")
        tk.Label(header, text=APP_NAME, font=("Segoe UI",18,"bold"),
                 bg=BG2, fg=TEXT, pady=16).pack(side="left", padx=24)

        # Badge NOUVEAU
        badge_frame = tk.Frame(header, bg=BG2)
        badge_frame.pack(side="right", padx=24, pady=16)
        tk.Label(badge_frame, text=f"v{APP_VERSION}",
                 font=("Segoe UI",10,"bold"), bg=BG2, fg=ACCENT2).pack(side="right", padx=(6,0))
        tk.Label(badge_frame, text="● NOUVEAU",
                 font=("Segoe UI",8,"bold"), bg=ACCENT, fg="white",
                 padx=6, pady=2).pack(side="right")

        tk.Frame(self, bg=BORDER, height=1).pack(fill="x")

        # Onglets
        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=0, pady=0)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=BG2, foreground=TEXT_DIM,
                         padding=[14,6], font=("Segoe UI",9))
        style.map("TNotebook.Tab",
                  background=[("selected", BG3)],
                  foreground=[("selected", ACCENT2)])

        # ── Onglet Accueil ────────────────────────────────────────────────────
        tab_home = tk.Frame(nb, bg=BG)
        nb.add(tab_home, text="  Accueil  ")

        card = tk.Frame(tab_home, bg=BG2)
        card.pack(fill="x", padx=24, pady=(20,12))

        tk.Label(card, text="État du système",
                 font=("Segoe UI",10,"bold"),
                 bg=BG2, fg=TEXT_DIM, anchor="w").pack(fill="x", padx=16, pady=(12,6))

        self.info_labels = {}
        rows = [
            ("Version installée", f"v{APP_VERSION}", ACCENT2),
            ("Précédente version", f"v{state.get('previous_version','—')}", TEXT_DIM),
            ("Dernière vérification", "En cours...", TEXT_DIM),
            ("Statut mise à jour", "Vérification...", AMBER),
        ]
        for key, val, col in rows:
            row = tk.Frame(card, bg=BG2)
            row.pack(fill="x", padx=16, pady=3)
            tk.Label(row, text=key + " :", font=("Segoe UI",9),
                     bg=BG2, fg=TEXT_DIM, width=22, anchor="w").pack(side="left")
            lbl = tk.Label(row, text=val, font=("Segoe UI",9,"bold"),
                           bg=BG2, fg=col, anchor="w")
            lbl.pack(side="left")
            self.info_labels[key] = lbl
        tk.Frame(card, bg=BG2, height=8).pack()

        # Nouveautés v1.1
        new_card = tk.Frame(tab_home, bg=BG3, bd=0)
        new_card.pack(fill="x", padx=24, pady=(0,12))
        header_new = tk.Frame(new_card, bg=ACCENT)
        header_new.pack(fill="x")
        tk.Label(header_new, text="  ✨ Nouveautés de la version 1.1",
                 font=("Segoe UI",9,"bold"), bg=ACCENT, fg="white",
                 pady=6, anchor="w").pack(fill="x", padx=4)
        for item in [
            "Interface améliorée avec onglets",
            "Historique complet des mises à jour",
            "Indicateur visuel de la nouvelle version",
            "Meilleure gestion des erreurs réseau",
        ]:
            tk.Label(new_card, text=f"  • {item}", font=("Segoe UI",9),
                     bg=BG3, fg=TEXT, anchor="w").pack(fill="x", padx=12, pady=2)
        tk.Frame(new_card, bg=BG3, height=8).pack()

        # Bouton vérification
        self.btn_check = tk.Button(tab_home,
                  text="🔄 Vérifier les mises à jour",
                  font=("Segoe UI",9), bg=BG2, fg=TEXT_DIM, relief="flat",
                  padx=12, pady=6, cursor="hand2",
                  command=self._check_update_async)
        self.btn_check.pack(pady=4)

        # ── Onglet Historique ─────────────────────────────────────────────────
        tab_hist = tk.Frame(nb, bg=BG)
        nb.add(tab_hist, text="  Historique  ")

        tk.Label(tab_hist, text="Historique des mises à jour",
                 font=("Segoe UI",11,"bold"), bg=BG, fg=TEXT,
                 pady=14).pack()

        hist_frame = tk.Frame(tab_hist, bg=BG2)
        hist_frame.pack(fill="both", expand=True, padx=24, pady=(0,16))

        history = state.get("history", [])
        if not history:
            tk.Label(hist_frame,
                     text="Aucune mise à jour enregistrée.\n(La v1.0 était la version initiale)",
                     font=("Segoe UI",10), bg=BG2, fg=TEXT_DIM,
                     pady=40).pack()
        else:
            for i, entry in enumerate(reversed(history[-10:])):
                row = tk.Frame(hist_frame, bg=BG2 if i%2==0 else BG3)
                row.pack(fill="x")
                tk.Label(row, text=f"  v{entry.get('version','?')}",
                         font=("Segoe UI",9,"bold"),
                         bg=row["bg"], fg=GREEN, width=8, anchor="w").pack(side="left", pady=8)
                tk.Label(row, text=entry.get("installed_at","?")[:19].replace("T"," "),
                         font=("Courier",8),
                         bg=row["bg"], fg=TEXT_DIM).pack(side="left")
                status = "✓ Succès" if entry.get("success") else "✗ Échec"
                col = GREEN if entry.get("success") else RED
                tk.Label(row, text=status,
                         font=("Segoe UI",8,"bold"),
                         bg=row["bg"], fg=col).pack(side="right", padx=16)

        # ── Onglet À propos ───────────────────────────────────────────────────
        tab_about = tk.Frame(nb, bg=BG)
        nb.add(tab_about, text="  À propos  ")

        tk.Label(tab_about, text=APP_NAME,
                 font=("Segoe UI",20,"bold"), bg=BG, fg=TEXT, pady=24).pack()
        tk.Label(tab_about, text=f"Version {APP_VERSION}",
                 font=("Segoe UI",12), bg=BG, fg=ACCENT2).pack()
        tk.Label(tab_about,
                 text="Système de mises à jour sécurisé\nRSA 4096 · SHA-256 · TLS 1.3",
                 font=("Segoe UI",9), bg=BG, fg=TEXT_DIM,
                 justify="center", pady=12).pack()

        # Pied de page
        tk.Label(self, text=f"{APP_NAME} v{APP_VERSION} — réseau local sécurisé",
                 font=("Segoe UI",8), bg=BG, fg=TEXT_DIM).pack(pady=6)

    def _check_update_async(self):
        self.btn_check.config(state="disabled", text="Vérification...")
        self.info_labels["Statut mise à jour"].config(text="Vérification...", fg=AMBER)
        threading.Thread(target=self._do_check, daemon=True).start()

    def _do_check(self):
        available, manifest = check_update_available()
        self.after(0, lambda: self._on_check_done(available, manifest))

    def _on_check_done(self, available, manifest):
        self.btn_check.config(state="normal", text="🔄 Vérifier les mises à jour")
        now = datetime.now().strftime("%H:%M:%S")
        self.info_labels["Dernière vérification"].config(text=now)
        if available:
            self.info_labels["Statut mise à jour"].config(
                text=f"v{manifest.get('version','?')} disponible", fg=AMBER)
            self.after(300, lambda: self._propose_update(manifest))
        else:
            self.info_labels["Statut mise à jour"].config(text="✓ À jour", fg=GREEN)

    def _propose_update(self, manifest):
        dialog = UpdateDialog(self, manifest)
        self.wait_window(dialog)
        if dialog.result:
            self._launch_update(manifest)

    def _launch_update(self, manifest):
        progress = ProgressDialog(self)
        self.update()

        def do_install():
            try:
                import requests, hashlib, zipfile, tempfile, shutil
                import urllib3
                urllib3.disable_warnings()

                cfg = configparser.ConfigParser()
                cfg.read(CONFIG_FILE, encoding="utf-8")
                server_url  = cfg["server"]["url"].rstrip("/")
                token       = cfg["server"]["token"]
                server_cert = cfg["server"].get("server_cert","false")
                verify = False if server_cert.lower() in ("false","no","0","") else server_cert
                headers = {"Authorization": f"Bearer {token}"}

                version  = manifest["version"]
                filename = manifest["filename"]
                expected_hash = manifest["sha256"]
                expected_size = manifest.get("size", 1)

                progress.update_progress(5, f"Téléchargement v{version}...")
                url = f"{server_url}/api/download/{version}/{filename}"
                resp = requests.get(url, headers=headers, verify=verify,
                                    stream=True, timeout=60)
                resp.raise_for_status()

                hasher = hashlib.sha256()
                downloaded = 0
                with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
                    tmp_path = Path(tmp.name)
                    for chunk in resp.iter_content(65536):
                        tmp.write(chunk)
                        hasher.update(chunk)
                        downloaded += len(chunk)
                        pct = min(88, 5 + (downloaded / expected_size) * 80)
                        progress.update_progress(pct, f"Téléchargement... {downloaded//1024} Ko")

                progress.update_progress(90, "Vérification de l'intégrité...")
                if hasher.hexdigest() != expected_hash:
                    progress.destroy()
                    messagebox.showerror("Erreur", "Hash invalide — fichier corrompu.")
                    tmp_path.unlink(missing_ok=True)
                    return

                progress.update_progress(93, "Sauvegarde...")
                backup_dir = BASE_DIR / "backups"
                backup_dir.mkdir(exist_ok=True)
                shutil.copy2(BASE_DIR / "app.py", backup_dir / f"app_v{APP_VERSION}.py")

                progress.update_progress(96, "Installation...")
                with zipfile.ZipFile(tmp_path, "r") as zf:
                    for name in zf.namelist():
                        if name.endswith("app.py"):
                            (BASE_DIR / "app.py").write_bytes(zf.read(name))
                            break

                tmp_path.unlink(missing_ok=True)

                state = load_state()
                state["previous_version"] = APP_VERSION
                state["installed_version"] = version
                if "history" not in state:
                    state["history"] = []
                state["history"].append({
                    "version": version,
                    "installed_at": datetime.now().isoformat(),
                    "success": True,
                })
                save_state(state)

                progress.update_progress(100)
                progress.done()
                self.after(1200, lambda: self._on_update_done(version, progress))

            except Exception as e:
                progress.destroy()
                messagebox.showerror("Erreur", f"Mise à jour échouée :\n{e}")

        threading.Thread(target=do_install, daemon=True).start()

    def _on_update_done(self, version, progress):
        progress.destroy()
        answer = messagebox.askyesno(
            "Mise à jour installée",
            f"✓ Version {version} installée avec succès !\n\nRelancer l'application maintenant ?")
        if answer:
            subprocess.Popen([sys.executable, str(BASE_DIR / "app.py")])
            self.quit()
            sys.exit(0)


if __name__ == "__main__":
    app = MainApp()
    app.mainloop()
