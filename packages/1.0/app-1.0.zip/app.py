#!/usr/bin/env python3
"""
app.py — Application principale v1.0
Mises à jour incrémentales : 1.0 → 1.1 → 1.2 → 1.3 étape par étape
"""

import sys, os, json, subprocess, configparser, threading, hashlib
import zipfile, tempfile, shutil, requests, urllib3
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from datetime import datetime

APP_VERSION = "1.0"
APP_NAME    = "MonApplication"
BASE_DIR    = Path(__file__).parent
CONFIG_FILE = BASE_DIR / "config.ini"
STATE_FILE  = BASE_DIR / "state.json"

# ── Couleurs ──────────────────────────────────────────────────────────────────
BG       = "#0f1117"
BG2      = "#1a1f2e"
BG3      = "#12192a"
ACCENT   = "#185FA5"
ACCENT2  = "#7EB8F7"
GREEN    = "#48bb78"
AMBER    = "#f6ad55"
RED      = "#fc8181"
TEXT     = "#e2e8f0"
TEXT_DIM = "#718096"
BORDER   = "#2d3748"

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ── State ─────────────────────────────────────────────────────────────────────
def load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE) as f: return json.load(f)
    return {"installed_version": APP_VERSION, "history": []}

def save_state(state):
    with open(STATE_FILE, "w") as f: json.dump(state, f, indent=2)

# ── Config ────────────────────────────────────────────────────────────────────
def get_session():
    cfg = configparser.ConfigParser()
    cfg.read(CONFIG_FILE, encoding="utf-8")
    url    = cfg["server"]["url"].rstrip("/")
    token  = cfg["server"]["token"]
    cert   = cfg["server"].get("server_cert", "false")
    verify = False if cert.lower() in ("false","no","0","") else cert
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {token}",
                       "User-Agent": f"MonApp/{APP_VERSION}"})
    s.verify = verify
    return s, url

# ── Versions ──────────────────────────────────────────────────────────────────
def parse_version(v):
    """'1.2.3' → (1, 2, 3)"""
    return tuple(int(x) for x in str(v).replace("v","").split("."))

def versions_between(current, all_versions):
    """
    Retourne toutes les versions > current, triées du plus ancien au plus récent.
    Ex: current='1.0', all=['1.3','1.2','1.1','1.0'] → ['1.1','1.2','1.3']
    """
    cur = parse_version(current)
    newer = [v for v in all_versions if parse_version(v) > cur]
    return sorted(newer, key=parse_version)

def get_all_versions(session, url):
    try:
        r = session.get(f"{url}/api/versions", timeout=5)
        r.raise_for_status()
        return r.json().get("versions", [])
    except Exception:
        return []

def get_manifest(session, url, version):
    r = session.get(f"{url}/api/manifest/{version}", timeout=5)
    r.raise_for_status()
    return r.json()

# ── Vérification rapide ───────────────────────────────────────────────────────
def check_updates_available():
    """
    Retourne (steps, latest) où steps = liste ordonnée des versions à installer.
    Ex: (['1.1','1.2','1.3'], '1.3') ou ([], None)
    """
    try:
        session, url = get_session()
        all_versions = get_all_versions(session, url)
        steps = versions_between(APP_VERSION, all_versions)
        if steps:
            return steps, steps[-1]
        return [], None
    except Exception:
        return [], None

# ── Téléchargement + installation d'une version ───────────────────────────────
def download_and_install(session, url, version, on_progress):
    """
    Télécharge, vérifie et installe une version.
    on_progress(pct, msg) — callback de progression.
    Retourne True si succès.
    """
    manifest = get_manifest(session, url, version)
    filename      = manifest["filename"]
    expected_hash = manifest["sha256"]
    expected_size = manifest.get("size", 1)

    on_progress(5, f"Téléchargement v{version}...")
    dl_url = f"{url}/api/download/{version}/{filename}"
    resp = session.get(dl_url, stream=True, timeout=60)
    resp.raise_for_status()

    hasher     = hashlib.sha256()
    downloaded = 0
    with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
        tmp_path = Path(tmp.name)
        for chunk in resp.iter_content(65536):
            tmp.write(chunk)
            hasher.update(chunk)
            downloaded += len(chunk)
            pct = min(75, 5 + (downloaded / expected_size) * 70)
            on_progress(pct, f"Téléchargement v{version}... {downloaded//1024} Ko")

    on_progress(80, "Vérification de l'intégrité...")
    if hasher.hexdigest() != expected_hash:
        tmp_path.unlink(missing_ok=True)
        raise ValueError(f"Hash invalide pour v{version} — fichier corrompu !")

    on_progress(88, "Sauvegarde...")
    backup_dir = BASE_DIR / "backups"
    backup_dir.mkdir(exist_ok=True)
    if (BASE_DIR / "app.py").exists():
        shutil.copy2(BASE_DIR / "app.py",
                     backup_dir / f"app_v{APP_VERSION}.py")

    on_progress(94, f"Installation v{version}...")
    with zipfile.ZipFile(tmp_path) as zf:
        for name in zf.namelist():
            if name.endswith("app.py"):
                (BASE_DIR / "app.py").write_bytes(zf.read(name))
                break

    tmp_path.unlink(missing_ok=True)

    state = load_state()
    state["previous_version"]  = state.get("installed_version", APP_VERSION)
    state["installed_version"] = version
    state.setdefault("history", []).append({
        "version":      version,
        "installed_at": datetime.now().isoformat(),
        "success":      True,
    })
    save_state(state)
    on_progress(100, f"✓ v{version} installée !")
    return True


# ─────────────────────────────────────────────────────────────────────────────
# Fenêtre de mise à jour incrémentale
# ─────────────────────────────────────────────────────────────────────────────
class IncrementalUpdateDialog(tk.Toplevel):
    """
    Affiche toutes les étapes à installer et les installe une par une.
    1.0 ──► 1.1 ──► 1.2 ──► 1.3
    """
    def __init__(self, parent, steps):
        super().__init__(parent)
        self.parent = parent
        self.steps  = steps          # ['1.1', '1.2', '1.3']
        self.result = False          # True si tout s'est bien passé
        self.final_version = steps[-1]

        self.title("Mise à jour en cours...")
        self.resizable(False, False)
        self.configure(bg=BG)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", lambda: None)  # bloque fermeture

        W, H = 500, 420 + len(steps) * 42
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{W}x{H}+{(sw-W)//2}+{(sh-H)//2}")

        self._build()
        # Lance l'installation après un court délai
        self.after(400, self._start_chain)

    # ── Construction de l'UI ──────────────────────────────────────────────────
    def _build(self):
        # En-tête
        tk.Frame(self, bg=ACCENT, height=4).pack(fill="x")
        tk.Label(self, text="🔄 Mise à jour en cours",
                 font=("Segoe UI", 14, "bold"),
                 bg=BG, fg=TEXT, pady=14).pack()
        tk.Label(self,
                 text=f"v{APP_VERSION}  →  v{self.final_version}  "
                      f"({len(self.steps)} étape{'s' if len(self.steps)>1 else ''})",
                 font=("Segoe UI", 10), bg=BG, fg=TEXT_DIM).pack(pady=(0, 14))

        # ── Étapes ────────────────────────────────────────────────────────────
        self.step_widgets = []
        prev = APP_VERSION

        steps_frame = tk.Frame(self, bg=BG2)
        steps_frame.pack(fill="x", padx=24, pady=(0, 14))

        for i, ver in enumerate(self.steps):
            row = tk.Frame(steps_frame, bg=BG2)
            row.pack(fill="x", padx=16, pady=6)

            # Icône état : ○ en attente / ⟳ en cours / ✓ fait / ✕ erreur
            icon_lbl = tk.Label(row, text="○",
                                 font=("Segoe UI", 13),
                                 bg=BG2, fg=TEXT_DIM, width=2)
            icon_lbl.pack(side="left")

            # Label "v1.0 → v1.1"
            tk.Label(row, text=f"v{prev}  →  v{ver}",
                     font=("Segoe UI", 10, "bold"),
                     bg=BG2, fg=TEXT_DIM).pack(side="left", padx=(6,0))

            # Statut texte
            status_lbl = tk.Label(row, text="En attente...",
                                   font=("Segoe UI", 9),
                                   bg=BG2, fg=TEXT_DIM)
            status_lbl.pack(side="right")

            self.step_widgets.append({
                "icon":   icon_lbl,
                "status": status_lbl,
                "ver":    ver,
            })
            prev = ver

        # ── Barre de progression de l'étape courante ──────────────────────────
        prog_frame = tk.Frame(self, bg=BG)
        prog_frame.pack(fill="x", padx=24)

        self.step_label = tk.Label(prog_frame, text="Préparation...",
                                    font=("Segoe UI", 9),
                                    bg=BG, fg=TEXT_DIM, anchor="w")
        self.step_label.pack(fill="x")

        self.step_bar = ttk.Progressbar(prog_frame, length=452,
                                         mode="determinate")
        self.step_bar.pack(fill="x", pady=4)

        self.step_pct = tk.Label(prog_frame, text="",
                                  font=("Segoe UI", 9),
                                  bg=BG, fg=TEXT_DIM, anchor="e")
        self.step_pct.pack(fill="x")

        # ── Barre de progression globale ──────────────────────────────────────
        tk.Label(self, text="Progression globale",
                 font=("Segoe UI", 8), bg=BG, fg=TEXT_DIM).pack(pady=(12,2))

        self.global_bar = ttk.Progressbar(self, length=452, mode="determinate")
        self.global_bar.pack(padx=24)

        self.global_pct = tk.Label(self, text="0 / " + str(len(self.steps)),
                                    font=("Segoe UI", 9, "bold"),
                                    bg=BG, fg=ACCENT2)
        self.global_pct.pack(pady=4)

        # ── Bouton fermé (affiché seulement à la fin) ─────────────────────────
        self.btn_done = tk.Button(self, text="Relancer l'application",
                                   font=("Segoe UI", 10, "bold"),
                                   bg=GREEN, fg="white", relief="flat",
                                   padx=20, pady=8, cursor="hand2",
                                   command=self._relaunch)
        # Ne s'affiche qu'à la fin

    # ── Mise à jour de l'UI depuis le thread ─────────────────────────────────
    def _set_step_state(self, idx, state, msg=""):
        """state: 'waiting' | 'running' | 'done' | 'error'"""
        w = self.step_widgets[idx]
        icons  = {"waiting": ("○", TEXT_DIM),
                  "running": ("⟳", AMBER),
                  "done":    ("✓", GREEN),
                  "error":   ("✕", RED)}
        icon_txt, icon_col = icons[state]
        status_col = {"waiting": TEXT_DIM, "running": AMBER,
                      "done": GREEN, "error": RED}[state]
        status_txt = {"waiting": "En attente...", "running": "Installation...",
                      "done": "✓ Installée", "error": "✕ Erreur"}[state]
        if msg and state in ("running", "error"):
            status_txt = msg

        w["icon"].config(text=icon_txt, fg=icon_col)
        w["status"].config(text=status_txt, fg=status_col)

        # Change aussi le label de l'étape
        ver_label_col = {"waiting": TEXT_DIM, "running": TEXT,
                         "done": TEXT_DIM, "error": RED}[state]
        # Trouve le label texte
        for child in w["icon"].master.winfo_children():
            if isinstance(child, tk.Label) and "→" in (child.cget("text") or ""):
                child.config(fg=ver_label_col)

    def _update_step_progress(self, pct, msg):
        self.step_bar["value"] = pct
        self.step_pct.config(text=f"{pct:.0f}%")
        if msg: self.step_label.config(text=msg)
        self.update()

    def _update_global(self, done):
        pct = (done / len(self.steps)) * 100
        self.global_bar["value"] = pct
        self.global_pct.config(text=f"{done} / {len(self.steps)} étapes")
        self.update()

    # ── Chaîne d'installation ─────────────────────────────────────────────────
    def _start_chain(self):
        threading.Thread(target=self._install_chain, daemon=True).start()

    def _install_chain(self):
        try:
            session, url = get_session()
        except Exception as e:
            self.after(0, lambda: messagebox.showerror(
                "Erreur", f"Impossible de se connecter :\n{e}"))
            self.after(0, self.destroy)
            return

        for i, version in enumerate(self.steps):
            # Marque comme "en cours"
            self.after(0, lambda i=i: self._set_step_state(i, "running"))
            self.after(0, lambda: self.step_bar.config(value=0))

            def on_progress(pct, msg, i=i):
                self.after(0, lambda: self._update_step_progress(pct, msg))

            try:
                download_and_install(session, url, version, on_progress)
                self.after(0, lambda i=i: self._set_step_state(i, "done"))
                self.after(0, lambda done=i+1: self._update_global(done))

            except Exception as e:
                self.after(0, lambda i=i, e=e:
                    self._set_step_state(i, "error", str(e)))
                self.after(0, lambda e=e: messagebox.showerror(
                    "Erreur d'installation",
                    f"Échec à l'étape v{version} :\n{e}\n\n"
                    "Les versions précédentes ont été installées."))
                return

        # Toutes les étapes terminées !
        self.result = True
        self.after(0, self._on_all_done)

    def _on_all_done(self):
        self.step_label.config(
            text=f"✓ Toutes les mises à jour installées !",
            fg=GREEN)
        self.step_bar["value"] = 100
        self.step_pct.config(text="100%", fg=GREEN)
        self.global_pct.config(
            text=f"✓ {len(self.steps)} / {len(self.steps)} étapes — Terminé !",
            fg=GREEN)
        self.btn_done.pack(pady=16)
        self.protocol("WM_DELETE_WINDOW", self._relaunch)

    def _relaunch(self):
        subprocess.Popen([sys.executable, str(BASE_DIR / "app.py")])
        self.parent.quit()
        sys.exit(0)


# ─────────────────────────────────────────────────────────────────────────────
# Boîte de dialogue : propose la mise à jour incrémentale
# ─────────────────────────────────────────────────────────────────────────────
class UpdateProposalDialog(tk.Toplevel):
    """Montre les étapes à venir et demande confirmation."""

    def __init__(self, parent, steps):
        super().__init__(parent)
        self.steps  = steps
        self.result = False
        self.title("Mise à jour disponible")
        self.resizable(False, False)
        self.configure(bg=BG)
        self.grab_set()

        W, H = 440, 300 + len(steps) * 28
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{W}x{H}+{(sw-W)//2}+{(sh-H)//2}")
        self._build()
        self.protocol("WM_DELETE_WINDOW", self._skip)

    def _build(self):
        tk.Frame(self, bg=ACCENT, height=4).pack(fill="x")

        tk.Label(self, text="🔄", font=("Segoe UI Emoji", 28),
                 bg=BG, fg=ACCENT2).pack(pady=(14, 4))

        final = self.steps[-1]
        n     = len(self.steps)

        tk.Label(self,
                 text=f"Mise à jour : v{APP_VERSION}  →  v{final}",
                 font=("Segoe UI", 13, "bold"),
                 bg=BG, fg=TEXT).pack()

        tk.Label(self,
                 text=f"{n} étape{'s' if n > 1 else ''} à installer dans l'ordre",
                 font=("Segoe UI", 9),
                 bg=BG, fg=TEXT_DIM).pack(pady=(2, 12))

        # Liste des étapes
        frame = tk.Frame(self, bg=BG2)
        frame.pack(fill="x", padx=28, pady=(0, 12))

        prev = APP_VERSION
        for i, ver in enumerate(self.steps):
            row = tk.Frame(frame, bg=BG2)
            row.pack(fill="x", padx=12, pady=4)

            # Numéro
            tk.Label(row, text=f"{i+1}.",
                     font=("Segoe UI", 9, "bold"),
                     bg=BG2, fg=TEXT_DIM, width=3, anchor="e").pack(side="left")

            # Flèche
            tk.Label(row, text=f"  v{prev}  →  v{ver}",
                     font=("Segoe UI", 10, "bold"),
                     bg=BG2, fg=TEXT).pack(side="left")

            # Badge "dernière" si c'est la finale
            if ver == self.steps[-1]:
                tk.Label(row, text="  ← cible",
                         font=("Segoe UI", 8),
                         bg=BG2, fg=ACCENT2).pack(side="left")

            prev = ver

        tk.Frame(frame, bg=BG2, height=8).pack()

        # Boutons
        btn_frame = tk.Frame(self, bg=BG)
        btn_frame.pack(pady=8)

        tk.Button(btn_frame,
                  text=f"Installer les {n} mise{'s' if n>1 else ''} à jour",
                  font=("Segoe UI", 10, "bold"),
                  bg=ACCENT, fg="white", relief="flat",
                  padx=16, pady=8, cursor="hand2",
                  activebackground="#1a6fc4", activeforeground="white",
                  command=self._accept).pack(side="left", padx=6)

        tk.Button(btn_frame, text="Plus tard",
                  font=("Segoe UI", 10),
                  bg=BG2, fg=TEXT_DIM, relief="flat",
                  padx=16, pady=8, cursor="hand2",
                  command=self._skip).pack(side="left", padx=6)

    def _accept(self): self.result = True;  self.destroy()
    def _skip(self):   self.result = False; self.destroy()


# ─────────────────────────────────────────────────────────────────────────────
# Fenêtre principale
# ─────────────────────────────────────────────────────────────────────────────
class MainApp(tk.Tk):

    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.resizable(False, False)
        self.configure(bg=BG)
        W, H = 520, 380
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{W}x{H}+{(sw-W)//2}+{(sh-H)//2}")
        self._build_ui()
        self.after(800, self._check_async)

    def _build_ui(self):
        tk.Frame(self, bg=ACCENT, height=4).pack(fill="x")

        # En-tête
        hdr = tk.Frame(self, bg=BG2)
        hdr.pack(fill="x")
        tk.Label(hdr, text=APP_NAME, font=("Segoe UI", 17, "bold"),
                 bg=BG2, fg=TEXT, pady=14).pack(side="left", padx=22)
        tk.Label(hdr, text=f"v{APP_VERSION}", font=("Segoe UI", 10),
                 bg=BG2, fg=ACCENT2, pady=14).pack(side="right", padx=22)
        tk.Frame(self, bg=BORDER, height=1).pack(fill="x")

        # Carte état
        card = tk.Frame(self, bg=BG2)
        card.pack(fill="x", padx=28, pady=20)
        tk.Label(card, text="État", font=("Segoe UI", 9, "bold"),
                 bg=BG2, fg=TEXT_DIM, anchor="w").pack(fill="x", padx=14, pady=(10,4))

        self.lbl = {}
        for key, val, col in [
            ("Version",       f"v{APP_VERSION}", ACCENT2),
            ("Vérification",  "En cours...",      TEXT_DIM),
            ("Mises à jour",  "...",              AMBER),
        ]:
            row = tk.Frame(card, bg=BG2)
            row.pack(fill="x", padx=14, pady=3)
            tk.Label(row, text=key+" :", font=("Segoe UI", 9),
                     bg=BG2, fg=TEXT_DIM, width=16, anchor="w").pack(side="left")
            l = tk.Label(row, text=val, font=("Segoe UI", 9, "bold"),
                         bg=BG2, fg=col, anchor="w")
            l.pack(side="left")
            self.lbl[key] = l
        tk.Frame(card, bg=BG2, height=8).pack()

        # Zone centrale
        mid = tk.Frame(self, bg=BG)
        mid.pack(fill="both", expand=True, padx=28)

        tk.Label(mid, text=f"Bienvenue dans {APP_NAME} !",
                 font=("Segoe UI", 12, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(8,4))
        tk.Label(mid,
                 text=f"Version {APP_VERSION} — vérification des mises à jour...",
                 font=("Segoe UI", 9),
                 bg=BG, fg=TEXT_DIM).pack()

        self.btn = tk.Button(mid, text="🔄 Vérifier maintenant",
                              font=("Segoe UI", 9),
                              bg=BG2, fg=TEXT_DIM, relief="flat",
                              padx=12, pady=6, cursor="hand2",
                              command=self._check_async)
        self.btn.pack(pady=12)

        tk.Label(self, text=f"{APP_NAME} — réseau local sécurisé",
                 font=("Segoe UI", 8), bg=BG, fg=TEXT_DIM).pack(pady=6)

    def _check_async(self):
        self.btn.config(state="disabled", text="Vérification...")
        self.lbl["Mises à jour"].config(text="Vérification...", fg=AMBER)
        threading.Thread(target=self._do_check, daemon=True).start()

    def _do_check(self):
        steps, latest = check_updates_available()
        self.after(0, lambda: self._on_check(steps, latest))

    def _on_check(self, steps, latest):
        self.btn.config(state="normal", text="🔄 Vérifier maintenant")
        now = datetime.now().strftime("%H:%M:%S")
        self.lbl["Vérification"].config(text=now, fg=TEXT_DIM)

        if steps:
            n = len(steps)
            self.lbl["Mises à jour"].config(
                text=f"{n} mise{'s' if n>1 else ''} à jour disponible{'s' if n>1 else ''} "
                     f"(v{steps[0]} → v{latest})",
                fg=AMBER)
            self.after(300, lambda: self._propose(steps))
        else:
            self.lbl["Mises à jour"].config(text="✓ À jour", fg=GREEN)

    def _propose(self, steps):
        dlg = UpdateProposalDialog(self, steps)
        self.wait_window(dlg)
        if dlg.result:
            IncrementalUpdateDialog(self, steps)

if __name__ == "__main__":
    MainApp().mainloop()
